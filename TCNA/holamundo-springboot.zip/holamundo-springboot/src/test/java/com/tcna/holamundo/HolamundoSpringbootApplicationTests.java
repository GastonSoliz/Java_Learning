package com.tcna.holamundo;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class HolamundoSpringbootApplicationTests {

	@Test
	void contextLoads() {
	}

}
